import numpy as np

from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn import svm
from PIL import Image

# Load the digits dataset
digits = datasets.load_digits()

x_train, x_test, y_train, y_test = train_test_split(digits.data, digits.target, test_size=0.2, random_state=42)

c1f = svm.SVC(gamma='scale')

c1f.fit(x_train, y_train)

test_image = Image.open("IMG1.jpg")
test_image = test_image.convert("L")
test_image = test_image.resize((8,8))
test_data = np.array(test_image).flatten()
test_data = test_data / 16.0

predicted = c1f.predict([test_data])

print("Predicted Digit:", predicted[0])
